### Hexlet tests and linter status:
[![Actions Status](https://github.com/korifei071987/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/korifei071987/python-project-49/actions)

# Maintainability badge
[![Maintainability](https://api.codeclimate.com/v1/badges/7afff18369a981ffb91b/maintainability)](https://codeclimate.com/github/korifei071987/python-project-49/maintainability)

# Asciinema links(external) brain-calc
[![asciicast](https://asciinema.org/a/NxcgqVRsTdckoiX8WGpct3ZWZ.svg)](https://asciinema.org/a/NxcgqVRsTdckoiX8WGpct3ZWZ)

# Asciinema links(external) brain-even
[![asciicast](https://asciinema.org/a/hspmgDWgkJctexdWSB8wMnFqq.svg)](https://asciinema.org/a/hspmgDWgkJctexdWSB8wMnFqq)

# Asciinema links(external) brain-gcd
[![asciicast](https://asciinema.org/a/FssLffoqB7Scc6G04K7jccje0.svg)](https://asciinema.org/a/FssLffoqB7Scc6G04K7jccje0)

# Asciinema links(external) brain-progression
[![asciicast](https://asciinema.org/a/LuI0W4vyrZjLGcTga2eSXgARh.svg)](https://asciinema.org/a/LuI0W4vyrZjLGcTga2eSXgARh)