### Hexlet tests and linter status:
[![Actions Status](https://github.com/korifei071987/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/korifei071987/python-project-49/actions)

# Maintainability badge
[![Maintainability](https://api.codeclimate.com/v1/badges/7afff18369a981ffb91b/maintainability)](https://codeclimate.com/github/korifei071987/python-project-49/maintainability)

# Asciinema links(external)
https://asciinema.org/connect/5c9e38a5-dd13-4078-a8f4-e3aaa4c8ca74
