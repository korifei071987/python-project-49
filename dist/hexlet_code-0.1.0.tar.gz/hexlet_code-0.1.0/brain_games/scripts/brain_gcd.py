from brain_games.games.game_engine_general import run_game
from brain_games.games import game_gcd
# BEGIN


def main():
    run_game(game_gcd)


if __name__ == '__main__':
    main()


# END
