def greet():
    print("Welcome to the Brain Games!")
