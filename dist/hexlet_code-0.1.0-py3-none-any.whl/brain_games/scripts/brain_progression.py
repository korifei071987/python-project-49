from brain_games.games.game_engine_general import run_game
from brain_games.games import game_progression
# BEGIN


def main():
    run_game(game_progression)


if __name__ == '__main__':
    main()


# END
