from brain_games.hello import greet
from brain_games.games.game_progression import main_progression
# BEGIN


def main():
    greet()
    main_progression()


if __name__ == '__main__':
    main()


# END
