from brain_games.hello import greet
from brain_games.games.game_gcd import gcd_main
# BEGIN


def main():
    greet()
    gcd_main()


if __name__ == '__main__':
    main()


# END
