from brain_games.hello import greet
from brain_games.games.game_prime import main_prime
# BEGIN


def main():
    greet()
    main_prime()


if __name__ == '__main__':
    main()


# END